}
function alfaSize($s) {
if($s >= 1073741824)
return sprintf('%1.2f', $s / 1073741824 ). ' GB';
elseif($s >= 1048576)
return sprintf('%1.2f', $s / 1048576 ) . ' MB';
elseif($s >= 1024)
return sprintf('%1.2f', $s / 1024 ) . ' KB';
else
return $s . ' B';
}
function alfaPerms($p) {
if (($p & 0xC000) == 0xC000)$i = 'sâ€‹';
elseif (($p & 0xA000) == 0xA000)$i = 'lâ€‹';
elseif (($p & 0x8000) == 0x8000)$i = '-â€‹';
elseif (($p & 0x6000) == 0x6000)$i = 'bâ€‹';
elseif (($p & 0x4000) == 0x4000)$i = 'dâ€‹';
elseif (($p & 0x2000) == 0x2000)$i = 'câ€‹';
elseif (($p & 0x1000) == 0x1000)$i = 'pâ€‹';
else $i = 'uâ€‹';
