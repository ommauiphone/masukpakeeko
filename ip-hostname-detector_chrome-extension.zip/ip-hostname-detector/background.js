// Background service worker
chrome.runtime.onInstalled.addListener(() => {
  console.log('IP & Hostname Detector installed');
});

// Mendengarkan perubahan tab
chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab.url && tab.url.startsWith('http')) {
      console.log('Tab aktif berubah:', tab.url);
    }
  });
});

// Mendengarkan update tab
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
    console.log('Tab selesai dimuat:', tab.url);
  }
});