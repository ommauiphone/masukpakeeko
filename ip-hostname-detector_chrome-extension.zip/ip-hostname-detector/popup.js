document.addEventListener('DOMContentLoaded', function() {
  getTabInfo();
  
  document.getElementById('refreshBtn').addEventListener('click', function() {
    getTabInfo();
  });
});

function getTabInfo() {
  const content = document.getElementById('content');
  content.innerHTML = `
    <div class="loading">
      <div class="spinner"></div>
      <p>Mendeteksi...</p>
    </div>
  `;

  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (tabs.length === 0) {
      showError('Tidak ada tab aktif');
      return;
    }

    const tab = tabs[0];
    const url = tab.url;
    
    if (!url || !url.startsWith('http')) {
      showError('Halaman ini tidak valid atau tidak menggunakan HTTP/HTTPS');
      return;
    }

    try {
      const urlObj = new URL(url);
      const hostname = urlObj.hostname;
      const protocol = urlObj.protocol.replace(':', '').toUpperCase();
      
      // Tampilkan hostname dulu
      displayInfo(hostname, url, protocol);
      
      // Dapatkan IP address menggunakan API
      getIPAddress(hostname, function(ip) {
        displayInfo(hostname, url, protocol, ip);
      });
      
    } catch (e) {
      showError('Error parsing URL: ' + e.message);
    }
  });
}

function getIPAddress(hostname, callback) {
  // Gunakan API gratis untuk mendapatkan IP
  fetch(`https://dns.google/resolve?name=${hostname}&type=A`)
    .then(response => response.json())
    .then(data => {
      if (data.Answer && data.Answer.length > 0) {
        const ip = data.Answer[0].data;
        callback(ip);
      } else {
        callback(null);
      }
    })
    .catch(() => {
      // Fallback ke API lain
      fetch(`https://api.ipify.org?format=json`)
        .then(response => response.json())
        .then(data => {
          callback(data.ip);
        })
        .catch(() => {
          callback(null);
        });
    });
}

function displayInfo(hostname, url, protocol, ip = null) {
  const content = document.getElementById('content');
  
  let html = `
    <div class="info-item">
      <div class="label">🌍 Domain / Hostname</div>
      <div class="value">${hostname}</div>
    </div>
  `;

  if (ip) {
    // Cek apakah IP public atau private
    const isPrivate = isPrivateIP(ip);
    const badge = isPrivate ? '🔒 Private' : '🌐 Public';
    
    html += `
      <div class="info-item">
        <div class="label">📡 IP Address <span class="badge">${badge}</span></div>
        <div class="value">${ip}</div>
      </div>
    `;
  } else {
    html += `
      <div class="info-item">
        <div class="label">📡 IP Address</div>
        <div class="value" style="color: #ffd93d;">Tidak dapat dideteksi</div>
      </div>
    `;
  }

  html += `
    <div class="info-item">
      <div class="label">🔗 URL Lengkap</div>
      <div class="value" style="font-size: 12px;">${url}</div>
    </div>
    <div class="info-item">
      <div class="label">📦 Protokol</div>
      <div class="value">${protocol}</div>
    </div>
  `;

  // Tambahan informasi
  html += `
    <div class="info-item">
      <div class="label">🕐 Waktu Deteksi</div>
      <div class="value" style="font-size: 12px;">${new Date().toLocaleString('id-ID')}</div>
    </div>
  `;

  content.innerHTML = html;
}

function showError(message) {
  const content = document.getElementById('content');
  content.innerHTML = `
    <div class="error">
      ⚠️ ${message}
    </div>
  `;
}

function isPrivateIP(ip) {
  // Cek apakah IP private
  const privateRanges = [
    /^10\./,
    /^172\.(1[6-9]|2[0-9]|3[0-1])\./,
    /^192\.168\./,
    /^127\./,
    /^169\.254\./
  ];
  
  return privateRanges.some(range => range.test(ip));
}